package com.dee.accounts.controller;

import com.dee.accounts.entity.Invoice;
import com.dee.accounts.repo.InvoiceRepository;
import com.sun.org.apache.xml.internal.utils.URI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.persistence.NoResultException;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.stream.Collectors;

@RestController
public class InvoiceController {

    //status used for an invoice to indicated paid, new & unbilled, bill sent & payment due
    private static final String INV_PAID = "PAID";
    private static final String INV_NEW = "NEW";
    private static final String INV_DUE = "DUE";

    @Autowired
    private InvoiceRepository invoiceRepository;

    @PostMapping("/create")
    public ResponseEntity createNewInvoice(@Valid @RequestBody Invoice invoice) {
        invoice.setSubmitData(LocalDate.now());
        invoiceRepository.save(invoice);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", new Date());
        body.put("status", HttpStatus.CREATED);
        body.put("message", "Invoice Submitted Successfully");
        body.put("invoice", invoice);

        return new ResponseEntity(body, HttpStatus.CREATED);
    }

    @PostMapping("/update/{id}")
    public ResponseEntity updateInvoiceAccount(@PathVariable @NotNull(message = "Invoice Id Must Be Provided!") Integer id, @Valid @RequestBody Invoice updatedInvoice){
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", new Date());

        try {
            Invoice invoice = invoiceRepository.findById(id).orElseThrow(()->new NoResultException("No records found for invoice id: " + id));
            invoiceRepository.save(updatedInvoice);
            body.put("status", HttpStatus.OK);
            body.put("message", "Invoice Updated");
            body.put("invoice", updatedInvoice);
            return new ResponseEntity(body, HttpStatus.OK);
        }catch(NoResultException e) {
            body.put("status", HttpStatus.NOT_FOUND);
            body.put("message", e.getLocalizedMessage());
            return new ResponseEntity(body, HttpStatus.NOT_FOUND);
        }catch (Exception e) {
            body.put("status", HttpStatus.INTERNAL_SERVER_ERROR);
            body.put("message", e.getLocalizedMessage());
            return new ResponseEntity(body, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/delete/{id}")
    public ResponseEntity deleteInvoiceAccountById(@PathVariable @NotNull(message = "Invoice Id Must Be Provided!") Integer id){
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", new Date());

        try {
            invoiceRepository.deleteById(id);
            body.put("status", HttpStatus.OK);
            body.put("message", "Invoice Deleted");
            return new ResponseEntity(body, HttpStatus.OK);
        }catch (Exception e) {
            body.put("status", HttpStatus.INTERNAL_SERVER_ERROR);
            body.put("message", e.getLocalizedMessage());
            return new ResponseEntity(body, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/find/{id}")
    public ResponseEntity findInvoiceAccountById(@PathVariable @NotNull(message = "Invoice Id Must Be Provided!")  Integer id){
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", new Date());

        try {
            Invoice invoice = invoiceRepository.findById(id).orElseThrow(()->new NoResultException("No records found for invoice id: " + id));
            body.put("status", HttpStatus.OK);
            body.put("message", "Invoice Found");
            body.put("invoice", invoice);
            return new ResponseEntity(body, HttpStatus.OK);
        }catch(NoResultException e) {
            body.put("status", HttpStatus.NOT_FOUND);
            body.put("message", e.getLocalizedMessage());
            return new ResponseEntity(body, HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/getOustandingFees/{custId}")
    public ResponseEntity getCustomerOutstanding(@PathVariable @NotNull(message = "customer id must be provided") Integer custId) {
        Map<String, Object> body = new LinkedHashMap<>();

        body.put("timestamp", new Date());

        try {

            List<Invoice> invoiceList = invoiceRepository.findByCustAccountIdAndAndStatus(custId, INV_DUE);

            if(invoiceList.isEmpty()){
                body.put("message", "no outstanding balance owed");
                body.put("fees", 0.0);
                return ResponseEntity.ok(body);
            }

            double total = invoiceList.stream().mapToDouble(Invoice::getTotal).sum();

            body.put("status", HttpStatus.OK);
            body.put("message", "outstanding balance found for customer");
            body.put("total", total);
            return new ResponseEntity(body, HttpStatus.OK);
        }catch(Exception e) {
            body.put("status", HttpStatus.INTERNAL_SERVER_ERROR);
            body.put("error", e.getStackTrace().toString());
            return new ResponseEntity(body, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//    @GetMapping("/find/surname/{id}")
//    public ResponseEntity getCustomersBySurname(@PathVariable @NotNull(message = "Customer Id Must Be Provided!")  Integer id){
//        Map<String, Object> body = new LinkedHashMap<>();
//        body.put("timestamp", new Date());
//
////        try {
////            Invoice invoice = invoiceRepository.findById(id).orElseThrow(()->new NoResultException("No records found for invoice id: " + id));
////            body.put("status", HttpStatus.OK);
////            body.put("message", "Invoice Found");
////            body.put("invoice", invoice);
////            return new ResponseEntity(body, HttpStatus.OK);
////        }catch(NoResultException e) {
////            body.put("status", HttpStatus.NOT_FOUND);
////            body.put("message", e.getLocalizedMessage());
////            return new ResponseEntity(body, HttpStatus.NOT_FOUND);
////        }
//    }

}
