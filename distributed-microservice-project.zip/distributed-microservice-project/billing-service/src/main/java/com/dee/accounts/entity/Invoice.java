/*
 * Copyright © GM Global Technology Operations LLC. All rights reserved.
 * This information is confidential and proprietary to GM Global Technology
 * Operations LLC and may not be used, modified, copied or distributed.
 */

package com.dee.accounts.entity;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
@Entity
public class Invoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull(message = "please proide a customer id")
    @Column(name = "cust_account_id")
    private Integer custAccountId;

    @NotNull(message = "please provide a total")
    @Column(name = "total")
    private double total;

    @NotBlank(message = "please provide details")
    @Column(name = "details")
    private String details;

    @NotBlank(message = "please provide a status")
    @Column(name = "status")
    private String status;

    @Column(name = "submit_date")
    private LocalDate submitData;
}
