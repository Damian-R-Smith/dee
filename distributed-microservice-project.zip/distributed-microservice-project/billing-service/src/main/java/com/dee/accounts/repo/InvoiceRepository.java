package com.dee.accounts.repo;

import com.dee.accounts.entity.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InvoiceRepository extends JpaRepository<Invoice, Integer> {

    List<Invoice> findByCustAccountIdAndAndStatus(Integer custAccountId, String status);

    List<Invoice> findByCustAccountId(Integer custAccountId);
}
