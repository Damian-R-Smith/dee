package com.dee.accounts;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "")
public interface BillingClient {
}
