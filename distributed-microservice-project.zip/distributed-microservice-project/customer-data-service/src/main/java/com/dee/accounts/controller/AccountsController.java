package com.dee.accounts.controller;

import com.dee.accounts.entity.Customer;
import com.dee.accounts.repo.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.persistence.NoResultException;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
public class AccountsController {

    @Autowired
    private CustomerRepository customerRepository;

    @PostMapping("/create")
    public ResponseEntity createNewCustomer(@Valid @RequestBody Customer customer) {
//        customer.setAccountCreateDate(LocalDate.now());
        customerRepository.save(customer);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", new Date());
        body.put("status", HttpStatus.CREATED);
        body.put("message", "Customer Submitted Successfully");
        body.put("customer", customer);

        return new ResponseEntity(body, HttpStatus.CREATED);
    }

    @PostMapping("/update/{id}")
    public ResponseEntity updateCustomerAccount(@PathVariable @NotNull(message = "Customer Id Must Be Provided!") Integer id, @Valid @RequestBody Customer updatedCustomer){
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", new Date());

        try {
            Customer customer = customerRepository.findById(id).orElseThrow(()->new NoResultException("No records found for customer id: " + id));
            customerRepository.save(updatedCustomer);
            body.put("status", HttpStatus.OK);
            body.put("message", "Customer Updated");
            body.put("customer", updatedCustomer);
            return new ResponseEntity(body, HttpStatus.OK);
        }catch(NoResultException e) {
            body.put("status", HttpStatus.NOT_FOUND);
            body.put("message", e.getLocalizedMessage());
            return new ResponseEntity(body, HttpStatus.NOT_FOUND);
        }catch (Exception e) {
            body.put("status", HttpStatus.INTERNAL_SERVER_ERROR);
            body.put("message", e.getLocalizedMessage());
            return new ResponseEntity(body, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/delete/{id}")
    public ResponseEntity deleteCustomerAccountById(@PathVariable @NotNull(message = "Customer Id Must Be Provided!") Integer id){
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", new Date());

        try {
            customerRepository.deleteById(id);
            body.put("status", HttpStatus.OK);
            body.put("message", "Customer Deleted");
            return new ResponseEntity(body, HttpStatus.OK);
        }catch (Exception e) {
            body.put("status", HttpStatus.INTERNAL_SERVER_ERROR);
            body.put("message", e.getLocalizedMessage());
            return new ResponseEntity(body, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/find/{id}")
    public ResponseEntity findCustomerAccountById(@PathVariable @NotNull(message = "Customer Id Must Be Provided!")  Integer id){
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", new Date());

        try {
            Customer customer = customerRepository.findById(id).orElseThrow(()->new NoResultException("No records found for customer id: " + id));
            body.put("status", HttpStatus.OK);
            body.put("message", "Customer Found");
            body.put("customer", customer);
            return new ResponseEntity(body, HttpStatus.OK);
        }catch(NoResultException e) {
            body.put("status", HttpStatus.NOT_FOUND);
            body.put("message", e.getLocalizedMessage());
            return new ResponseEntity(body, HttpStatus.NOT_FOUND);
        }
    }

//    @GetMapping("/find/newBilling")
//    public void getAllCustomersPastBillPeriod() {
//        Map<String, Object> body = new LinkedHashMap<>();
//        body.put("timestamp", new Date());
//
//        try {
//            Customer customer = customerRepository.findById(id).orElseThrow(()->new NoResultException("No records found for customer id: " + id));
//            body.put("status", HttpStatus.OK);
//            body.put("message", "Customer Found");
//            body.put("customer", customer);
//            return new ResponseEntity(body, HttpStatus.OK);
//        }catch(NoResultException e) {
//            body.put("status", HttpStatus.NOT_FOUND);
//            body.put("message", e.getLocalizedMessage());
//            return new ResponseEntity(body, HttpStatus.NOT_FOUND);
//        }
//    }
}
