package com.dee.accounts.entity;

import lombok.Data;
import org.hibernate.annotations.CollectionId;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@Entity
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "full_name")
    private String fullName;

    @Column(name = "billing_addr")
    private String billingAddr;

    @Column(name = "email")
    private String emailAddr;

    @Column(name = "surname")
    private String surname;

    @Column(name = "last_bill_date")
    private LocalDate lastBillDate;


}
