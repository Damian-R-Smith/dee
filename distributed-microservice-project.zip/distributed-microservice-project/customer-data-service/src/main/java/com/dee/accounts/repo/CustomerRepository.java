package com.dee.accounts.repo;

import com.dee.accounts.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

    List<Customer> findCustomersByLastBillDateIsBefore(LocalDate billPeriod);
}
