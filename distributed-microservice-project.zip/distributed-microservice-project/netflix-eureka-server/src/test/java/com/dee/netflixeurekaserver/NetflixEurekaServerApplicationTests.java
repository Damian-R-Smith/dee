package com.dee.netflixeurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetflixEurekaServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
